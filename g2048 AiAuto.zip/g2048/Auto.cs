﻿using System;
using System.Collections.Generic;
using System.Text;

namespace g2048
{
    public static class Auto
    {
        public static string AutoPlay(int[] pos)
        {
            //场上每一个2^n得n*2^n*数量分
            //如果消不掉，假设不出新进行一次操作，再调用之前的方法判断可能的最大得分。
            string choice = "w";
            double bestScore = GetMax(WScoreEventually(pos), SScoreEventually(pos), AScoreEventually(pos), DScoreEventually(pos));
            if (WScoreEventually(pos) == bestScore)
            {
                choice = "w";
            }
            if (SScoreEventually(pos) == bestScore)
            {
                choice = "s";
            }
            if (AScoreEventually(pos) == bestScore)
            {
                choice = "a";
            }
            if (DScoreEventually(pos) == bestScore)
            {
                choice = "d";
            }
            return choice;
        }
        public static void WChange(ref int[] pos)
        {
            bool[] judge = new bool[16];
            for (int i = 0; i < 16; i++)
            {
                judge[i] = true;
            }
            for (int k = 0; k < 4 - 1; k++)
            {
                for (int j = 1; j < 4; j++)
                {
                    for (int i = 0; i < 4; i++)
                    {
                        if (pos[4 * j + i] == pos[i + 4 * (j - 1)] && pos[4 * j + i] != 0 && judge[i + 4 * (j - 1)] && judge[i + 4 * j])
                        {
                            pos[i + 4 * (j - 1)] = 2 * pos[i + 4 * (j - 1)];
                            pos[4 * j + i] = 0;
                            judge[i + 4 * (j - 1)] = false;
                        }
                        if (pos[4 * j + i - 4] == 0)
                        {
                            pos[i + 4 * (j - 1)] = pos[i + 4 * j];
                            pos[4 * j + i] = 0;
                        }

                    }

                }

            }
        }

        public static void SChange(ref int[] pos)
        {
            bool[] judge = new bool[16];
            for (int k = 0; k < 4 - 1; k++)
            {
                for (int j = 4 - 1; j > 0; j--)
                {
                    for (int i = 0; i < 4; i++)
                    {
                        if (pos[4 * j + i] == pos[i + 4 * j - 4] && pos[4 * j + i] != 0 && judge[i + 4 * j] && judge[i + 4 * j - 4])
                        {
                            pos[i + 4 * j] = 2 * pos[i + 4 * j - 4];
                            pos[4 * j + i - 4] = 0;
                            judge[i + 4 * j] = false;
                        }
                        if (pos[4 * j + i] == 0)
                        {
                            pos[i + 4 * j] = pos[i + 4 * j - 4];
                            pos[4 * j + i - 4] = 0;
                        }

                    }

                }

            }
        }

        public static void AChange(ref int[] pos)
        {
            bool[] judge = new bool[16];
            for (int k = 0; k < 4 - 1; k++)
            {
                for (int j = 1; j < 4; j++)
                {
                    for (int i = 0; i < 4; i++)
                    {
                        if (pos[4 * i + j - 1] == pos[j + 4 * i] && pos[4 * i + j] != 0 && judge[j + 4 * i - 1] && judge[j + 4 * i])
                        {
                            pos[j + 4 * i - 1] = 2 * pos[j + 4 * i];
                            pos[4 * i + j] = 0;
                            judge[i + 4 * j - 1] = false;
                        }
                        if (pos[4 * i + j - 1] == 0)
                        {
                            pos[j + 4 * i - 1] = pos[j + 4 * i];
                            pos[4 * i + j] = 0;
                        }

                    }

                }

            }
        }

        public static void DChange(ref int[] pos)
        {
            bool[] judge = new bool[16];
            for (int k = 0; k < 4 - 1; k++)
            {
                for (int j = 4 - 1; j > 0; j--)
                {
                    for (int i = 0; i < 4; i++)
                    {
                        if (pos[4 * i + j - 1] == pos[j + 4 * i] && pos[4 * i + j] != 0 && judge[j + 4 * i] && judge[j + 4 * i - 1])
                        {
                            pos[j + 4 * i] = 2 * pos[j + 4 * i];
                            pos[4 * i + j - 1] = 0;
                            judge[j + 4 * i] = false;
                        }
                        if (pos[4 * i + j] == 0)
                        {
                            pos[j + 4 * i] = pos[j + 4 * i - 1];
                            pos[4 * i + j - 1] = 0;
                        }

                    }

                }

            }
        }
        public static double WScoreInitially(int[] pos)
        {
            WChange(ref pos);
            double score = 0;
            for (int i = 0; i < 16; i++)
            {
                score += pos[i] * Math.Log2(pos[i]);
            }
            return score;
        }

        public static double SScoreInitially(int[] pos)
        {
            SChange(ref pos);
            double score = 0;
            for (int i = 0; i < 16; i++)
            {
                score += pos[i] * Math.Log2(pos[i]);
            }
            return score;
        }

        public static double AScoreInitially(int[] pos)
        {
            AChange(ref pos);
            double score = 0;
            for (int i = 0; i < 16; i++)
            {
                score += pos[i] * Math.Log2(pos[i]);
            }
            return score;
        }

        public static double DScoreInitially(int[] pos)
        {
            DChange(ref pos);
            double score = 0;
            for (int i = 0; i < 16; i++)
            {
                score += pos[i] * Math.Log2(pos[i]);
            }
            return score;
        }

        public static double GetMax(double x1, double x2, double x3, double x4)
        {
            double x = x1;
            if (x2 >= x)
            {
                x = x2;
            }
            if (x3 >= x)
            {
                x = x3;
            }
            if (x4 >= x)
            {
                x = x4;
            }
            return x;
        }

        public static double WScoreEventually(int[] pos)
        {
            double score = WScoreInitially(pos);
            WChange(ref pos);
            score += (GetMax(WScoreInitially(pos), SScoreInitially(pos), AScoreInitially(pos), DScoreInitially(pos))) / 2;
            return score;
        }

        public static double SScoreEventually(int[] pos)
        {
            double score = SScoreInitially(pos);
            SChange(ref pos);
            score += (GetMax(WScoreInitially(pos), SScoreInitially(pos), AScoreInitially(pos), DScoreInitially(pos))) / 2;
            return score;
        }

        public static double AScoreEventually(int[] pos)
        {
            double score = AScoreInitially(pos);
            AChange(ref pos);
            score += (GetMax(WScoreInitially(pos), SScoreInitially(pos), AScoreInitially(pos), DScoreInitially(pos))) / 2;
            return score;
        }

        public static double DScoreEventually(int[] pos)
        {
            double score = DScoreInitially(pos);
            DChange(ref pos);
            score += (GetMax(WScoreInitially(pos), SScoreInitially(pos), AScoreInitially(pos), DScoreInitially(pos))) / 2;
            return score;
        }

    }
}
