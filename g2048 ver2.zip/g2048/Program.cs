﻿using System;

namespace g2048
{
    class Program
    {
        static void Main(string[] args)
        {
            bool judge2 = true;
            bool judge3 = true;
            Console.WriteLine("input level");
            int level = Convert.ToInt32(Console.ReadLine());
            int[] pos = new int[level * level];
            while (judge3)
            {
                Console.Clear();
                //add randomly a number first
                Random r = new Random();
                int rNumber = r.Next(0, level * level);
                while (pos[rNumber] != 0)
                {
                    rNumber = r.Next(0, level * level);
                }
                if (judge2)
                {
                    pos[rNumber] = 1;
                }
                else
                {
                    judge2 = true;
                }

                for (int i = 0; i < level; i++)
                {
                    for (int j = 0; j < level; j++)
                    {
                        Console.Write(pos[level * i + j] + "   ");
                    }
                    for (int j = 0; j < 3; j++)
                    {
                        Console.WriteLine();
                    }
                }
                string input = Console.ReadLine();
                bool[] judge = new bool[level * level];
                for (int i = 0; i < level * level; i++)
                {
                    judge[i] = true;
                }
                switch (input)
                {
                    case "w":
                        for (int k = 0; k < level - 1; k++)
                        {
                            for (int j = 1; j < level; j++)
                            {
                                for (int i = 0; i < level; i++)
                                {
                                    if (pos[level * j + i] == pos[i + level * (j - 1)] && pos[level * j + i] != 0 && judge[i + level * (j - 1)] && judge[i + level * j])
                                    {
                                        pos[i + level * (j - 1)] = 2 * pos[i + level * (j - 1)];
                                        pos[level * j + i] = 0;
                                        judge[i + level * (j - 1)] = false;
                                    }
                                    if (pos[level * j + i - level] == 0)
                                    {
                                        pos[i + level * (j - 1)] = pos[i + level * j];
                                        pos[level * j + i] = 0;
                                    }

                                }

                            }

                        }
                        break;
                    case "s":
                        for (int k = 0; k < level - 1; k++)
                        {
                            for (int j = level - 1; j > 0; j--)
                            {
                                for (int i = 0; i < level; i++)
                                {
                                    if (pos[level * j + i] == pos[i + level * j - level] && pos[level * j + i] != 0 && judge[i + level * j] && judge[i + level * j - level])
                                    {
                                        pos[i + level * j] = 2 * pos[i + level * j - level];
                                        pos[level * j + i - level] = 0;
                                        judge[i + level * j] = false;
                                    }
                                    if (pos[level * j + i] == 0)
                                    {
                                        pos[i + level * j] = pos[i + level * j - level];
                                        pos[level * j + i - level] = 0;
                                    }

                                }

                            }

                        }
                        break;
                    case "a":
                        for (int k = 0; k < level - 1; k++)
                        {
                            for (int j = 1; j < level; j++)
                            {
                                for (int i = 0; i < level; i++)
                                {
                                    if (pos[level * i + j - 1] == pos[j + level * i] && pos[level * i + j] != 0 && judge[j + level * i - 1] && judge[j + level * i])
                                    {
                                        pos[j + level * i - 1] = 2 * pos[j + level * i];
                                        pos[level * i + j] = 0;
                                        judge[i + level * j - 1] = false;
                                    }
                                    if (pos[level * i + j - 1] == 0)
                                    {
                                        pos[j + level * i - 1] = pos[j + level * i];
                                        pos[level * i + j] = 0;
                                    }

                                }

                            }

                        }
                        break;
                    case "d":
                        for (int k = 0; k < level - 1; k++)
                        {
                            for (int j = level - 1; j > 0; j--)
                            {
                                for (int i = 0; i < level; i++)
                                {
                                    if (pos[level * i + j - 1] == pos[j + level * i] && pos[level * i + j] != 0 && judge[j + level * i] && judge[j + level * i - 1])
                                    {
                                        pos[j + level * i] = 2 * pos[j + level * i];
                                        pos[level * i + j - 1] = 0;
                                        judge[j + level * i] = false;
                                    }
                                    if (pos[level * i + j] == 0)
                                    {
                                        pos[j + level * i] = pos[j + level * i - 1];
                                        pos[level * i + j - 1] = 0;
                                    }

                                }

                            }

                        }
                        break;
                    default:
                        Console.WriteLine("You have put in an undefined letter,please try again.");
                        Console.WriteLine("press any key to continue.");
                        judge2 = false;
                        Console.ReadKey();
                        break;
                }

                for (int i = 0; i < 16; i++)
                {
                    if (pos[i] == 0)
                    {
                        judge3 = true;
                        break;
                    }
                    else
                    {
                        judge3 = false;
                    }
                }

            }
            Console.WriteLine("ends");
        }
    }
}

